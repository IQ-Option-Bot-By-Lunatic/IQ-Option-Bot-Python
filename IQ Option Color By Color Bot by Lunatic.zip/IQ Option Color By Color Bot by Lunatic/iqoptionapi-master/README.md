# Iqoption API

great robot
https://npt-life.com/iq-option-robot

Iqoption API private version https://npt-life.com/iq-option-api

olymptrade API https://npt-life.com/other-apis

Pock Option API https://npt-life.com/other-apis

## Document

### New document

https://lu-yi-hsun.github.io/iqoptionapi/
 
### Old document

old document not support anymore:
https://github.com/Lu-Yi-Hsun/iqoptionapi_private/blob/master/old_document.md
