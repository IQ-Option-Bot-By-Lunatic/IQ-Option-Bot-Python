from iqoptionapi.stable_api import IQ_Option
Iq=IQ_Option("email","password")
ch,fa=Iq.connect()
print('Start running...')
'''
Trade follow by previous win order
-------------------------
>>> Change the setting here <<<
-------------------------
'''
MODE="PRACTICE" #"REAL" & "PRACTICE"
XCurrency="EURUSD-OTC" #Currency ex. EURUSD or EURUSD-OTC
Xmultiply=2.25 #martingale multiplier to increase bet after loss
Xmartingal=4 #max martingale you can accept
Xprofit=100 #profit (bot will stop if you gain => Xprofit)
Xloss=-100 #max loss (bot will stop if you lost <= Xloss)
XDuration=1 #order duration (1 or 5 or 10 minute)
XMoney=1 #money you bet per order
Xsize=60 #candles size (ex. 60 second)
'''
>>> How to Manually stop Bot <<<
 1. Click on the Terminal below
 2. Press Ctrl + C
 3. Done
'''
Iq.change_balance(MODE)
profit=0
gain=0
loss=0
Call=1
Put=0
martingal=0
while profit < Xprofit:
    Currency=XCurrency
    Duration=XDuration #minute 1 or 5
    Money=XMoney  
    if martingal > 0:
        Money = Money*(Xmultiply**martingal) 
    if profit <= Xloss or martingal > Xmartingal:
        break
    elif Call == 1:
        _,id=(Iq.buy_digital_spot(Currency,Money,"call",Duration)) 
        print('-------------------------------------') 
        print('Call')
        print('-------------------------------------')    
        if id !="error":     
            while True:     
               check,win=Iq.check_win_digital_v2(id)     
               if check==True:     
                   break     
            if win==0:     
               print('Nothing : ',str(win)+' $')     
            elif win<0:     
               print('You Loss : ',str('%.2f'%win)+' $')
               profit += win
               loss += 1
               martingal += 1                   
               Put = 1      
               Call = 0            
            else:     
               print('You Win : ',str('%.2f'%win)+' $')
               profit += win
               gain += 1
               martingal = 0
               Put = 0
               Call = 1                 
        else:     
            print("please try again")    
    elif Put == 1:     
        _,id=(Iq.buy_digital_spot(Currency,Money,"put",Duration))     
        print('-------------------------------------') 
        print('Put')
        print('-------------------------------------')  
        if id !="error":     
            while True:     
               check,win=Iq.check_win_digital_v2(id)     
               if check==True:     
                   break     
            if win==0:     
               print('Nothing : ',str(win)+' $')     
            elif win<0:     
               print('You Loss : ',str('%.2f'%win)+' $')
               profit += win
               loss += 1
               martingal += 1 
               Put = 0
               Call = 1          
            else:     
               print('You Win : ',str('%.2f'%win)+' $')
               profit += win
               gain += 1 
               martingal = 0                     
               Put = 1 
               Call = 0
        else:     
            print("please try again")
    print('Gain : ',str(gain)) 
    print('Loss : ',str(loss))
    print('Martingal : ',str(martingal))
    print('Winrate : ',str('%.2f'%(gain/(gain+loss)*100))+' %')
    print('Profit : ',str('%.2f'%profit)+' $')