from iqoptionapi.stable_api import IQ_Option
Iq=IQ_Option("email","password")
ch,fa=Iq.connect()
print('Start running...')
'''
IQ option color by color bot
-------------------------
>>> Change the setting here <<<
-------------------------
'''
MODE="PRACTICE" #"REAL" & "PRACTICE"
XCurrency="EURUSD-OTC" #Currency ex. EURUSD or EURUSD-OTC
Xmultiply=2.25 #martingale multiplier to increase bet after loss
Xmartingale=4 #max martingale you can accept
Xprofit=100 #profit (bot will stop if you gain => Xprofit)
Xloss=-100  #max loss (bot will stop if you lost <= Xloss)
XDuration=1 #order duration (1 or 5 or 10 minute)
XMoney=1 #money you bet per order
Xsize=60 #candles size
'''
>>> How to Manually stop Bot <<<
 1. Click on the Terminal below
 2. Press Ctrl + C
 3. Done
'''
Iq.change_balance(MODE)
profit=0
gain=0
loss=0
martingal=0
while profit < Xprofit:
    Currency=XCurrency
    Duration=XDuration
    Money=XMoney 
    green=0
    red=0 
    if martingal > 0:
        Money = Money*(Xmultiply**martingal)
    size=Xsize
    maxdict=1
    Iq.start_candles_stream(Currency,size,maxdict)
    realtime = Iq.get_realtime_candles(Currency,size)  
    real_time = (dict(realtime))  
    for i in real_time:     
        OpenA = realtime[i]['open']     
        CloseA = realtime[i]['close']         
        Type_candle = (OpenA)-(CloseA)     
        if Type_candle<-0.0:     
            green = 1
        elif Type_candle>0.0:
            red = 1
    if profit <= Xloss or martingal > Xmartingale:
        break
    elif green == 1:
        _,id=(Iq.buy_digital_spot(Currency,Money,"call",Duration))     
        print('-------------------------------') 
        print('call')
        print('-------------------------------')     
        if id !="error":     
            while True:     
               check,win=Iq.check_win_digital_v2(id)     
               if check==True:     
                   break     
            if win==0:     
               print('Nothing : ',str(win)+' $')     
            elif win<0:     
               print('You Loss : ',str('%.2f'%win)+' $')
               profit += win
               loss += 1
               martingal += 1                                 
            else:     
               print('You Win : ',str('%.2f'%win)+' $')
               profit += win
               gain += 1
               martingal = 0                
        else:     
            print("please try again")    
    elif red == 1:     
        _,id=(Iq.buy_digital_spot(Currency,Money,"put",Duration))     
        print('-------------------------------') 
        print('put')
        print('-------------------------------')      
        if id !="error":     
            while True:     
               check,win=Iq.check_win_digital_v2(id)     
               if check==True:     
                   break     
            if win==0:     
               print('Nothing : ',str(win)+' $')     
            elif win<0:     
               print('You Loss : ',str('%.2f'%win)+' $')
               profit += win
               loss += 1
               martingal += 1     
            else:     
               print('You Win : ',str('%.2f'%win)+' $')
               profit += win
               gain += 1 
               martingal = 0                           
        else:     
            print("please try again")
    print('Gain : ',str(gain)) 
    print('Loss : ',str(loss))
    print('Martingale : ',str(martingal))
    print('Winrate : ',str('%.2f'%(gain/(gain+loss)*100))+' %')
    print('Profit : ',str('%.2f'%profit)+' $')